# SmartSDLC Deployment Guide

## Quick Deploy on Render (Recommended)

### Step 1: Prepare Your Repository
Your code is already on GitHub at `https://github.com/techdollar/smart-sdlc.git`

### Step 2: Deploy on Render
1. Go to [render.com](https://render.com) and sign up/login
2. Click "New +" → "Web Service"
3. Connect your GitHub repository: `techdollar/smart-sdlc`
4. Configure the service:
   - **Name**: `smartsdlc-backend`
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r backend/requirements.txt`
   - **Start Command**: `cd backend && uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Plan**: Free

### Step 3: Set Environment Variables
In your Render service settings, add these environment variables:
- `HUGGINGFACE_API_KEY`: Your Hugging Face API key
- `IBM_CLOUD_API_KEY`: Your IBM Cloud API key (if using Watsonx)

### Step 4: Deploy
Click "Create Web Service" and wait for deployment (5-10 minutes)

### Step 5: Access Your App
Your app will be available at: `https://your-app-name.onrender.com`

## Alternative Deployment Options

### Option 2: Railway
1. Go to [railway.app](https://railway.app)
2. Connect your GitHub repo
3. Deploy with similar settings as Render

### Option 3: Heroku
1. Create a `Procfile` in the root:
   ```
   web: cd backend && uvicorn main:app --host=0.0.0.0 --port=$PORT
   ```
2. Deploy via Heroku CLI or GitHub integration

### Option 4: Vercel (Frontend) + Render (Backend)
1. Deploy backend on Render as above
2. Deploy frontend on Vercel:
   - Push `frontend/` folder to a separate repo
   - Import to Vercel
   - Update API URLs in `script.js` to point to your Render backend

## Environment Variables Required

Make sure to set these in your deployment platform:
- `HUGGINGFACE_API_KEY`: For AI chatbot functionality
- `IBM_CLOUD_API_KEY`: For Watsonx integration (optional)

## Post-Deployment Checklist

- [ ] Test the main page loads
- [ ] Test file upload functionality
- [ ] Test chatbot responses
- [ ] Test all other features (code generation, bug fixing, etc.)
- [ ] Check that static files are served correctly
- [ ] Verify API endpoints are working

## Troubleshooting

### Common Issues:
1. **Build fails**: Check `requirements.txt` is complete
2. **API errors**: Verify environment variables are set
3. **Static files not loading**: Check file paths in `main.py`
4. **Database errors**: SQLite file permissions on deployment platform

### Debug Commands:
- Check logs in your deployment platform dashboard
- Test API endpoints: `https://your-app.onrender.com/health`
- Test main page: `https://your-app.onrender.com/`

## Local Development vs Production

- **Local**: Uses `http://127.0.0.1:8000`
- **Production**: Uses relative paths (`/api`, `/health`)
- **Database**: SQLite file (consider PostgreSQL for production)
- **Storage**: File-based (consider cloud storage for production)

## Next Steps After Deployment

1. Set up a custom domain (optional)
2. Configure SSL certificates (usually automatic)
3. Set up monitoring and logging
4. Consider database migration to PostgreSQL
5. Set up automated backups 