# 🚀 SmartSDLC - AI-Powered Software Development Lifecycle

A comprehensive AI-powered platform that automates and enhances various phases of the Software Development Lifecycle (SDLC) with integrated storage, database, and session management.

## ✨ Features

### 🔧 Core SDLC Features
- **📋 Requirements Classification**: Upload PDF requirements and automatically classify them into SDLC phases
- **💻 AI Code Generation**: Generate production-ready code from natural language descriptions
- **🐛 Bug Detection & Fixing**: Analyze code for bugs and provide automated fixes
- **🧪 Test Case Generation**: Generate comprehensive test cases for your code
- **📚 Code Summarization**: Create documentation and summaries from code
- **🤖 AI Chatbot Assistant**: Interactive AI assistant for SDLC guidance

### 💾 Storage System
- **📁 File Storage**: Organized file management for uploads and generated content
- **🗄️ Database Storage**: SQLite database for persistent data storage
- **💬 Session Management**: User session handling with preferences and context

## 🏗️ Architecture

### Backend (FastAPI)
```
backend/
├── main.py                 # FastAPI application entry point
├── models.py              # SQLAlchemy database models
├── storage.py             # File storage utilities
├── sessions.py            # Session management
├── requirements.txt       # Python dependencies
├── routers/               # API route handlers
│   ├── classifier.py      # Requirements classification
│   ├── codegen.py         # Code generation
│   ├── bugfix.py          # Bug detection & fixing
│   ├── testgen.py         # Test case generation
│   ├── summarizer.py      # Code summarization
│   └── chatbot.py         # AI chatbot
├── utils/                 # Utility functions
│   └── huggingface.py     # AI model integration
├── storage/               # File storage directories
│   ├── uploads/           # User uploaded files
│   ├── generated/         # AI-generated content
│   └── temp/              # Temporary files
└── database/              # SQLite database files
```

### Frontend (HTML/JavaScript)
```
frontend/
├── index.html            # Main application page
├── script.js             # Frontend JavaScript
├── style.css             # Styling
├── requirement.html      # Requirements page
├── codegen.html          # Code generation page
├── bugfix.html           # Bug fixing page
├── testgen.html          # Test generation page
└── summarizer.html       # Code summarization page
```

## 🗄️ Database Schema

### Core Tables
- **Users**: User accounts and authentication
- **Files**: Uploaded files and metadata
- **Conversations**: Chat conversations
- **Messages**: Individual chat messages
- **UserSessions**: User session data
- **CodeGeneration**: Generated code history
- **BugFix**: Bug analysis history
- **TestGeneration**: Generated test history
- **CodeSummary**: Code summarization history

## 📁 Storage Structure

### File Storage
```
storage/
├── uploads/
│   ├── pdfs/             # Uploaded PDF requirements
│   ├── images/           # Uploaded images
│   └── documents/        # Other documents
├── generated/
│   ├── code/             # Generated code files
│   ├── tests/            # Generated test files
│   └── docs/             # Generated documentation
└── temp/                 # Temporary files (auto-cleaned)
```

### Database Storage
- **SQLite Database**: `database/smartsdlc.db`
- **Automatic cleanup**: Expired sessions and temporary files
- **Data persistence**: All user interactions and generated content

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip (Python package manager)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd smartsdlc_zip
   ```

2. **Start with Storage System (Recommended)**
   ```bash
   # Windows
   start_with_storage.bat
   
   # Or manually
   cd backend
   python start_with_storage.py
   ```

3. **Alternative: Start without Storage**
   ```bash
   cd backend
   python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
   ```

4. **Access the Application**
   - Frontend: http://127.0.0.1:8000
   - API Documentation: http://127.0.0.1:8000/docs
   - Health Check: http://127.0.0.1:8000/health

## 📋 Usage Guide

### 1. Requirements Classification
1. Navigate to "Requirements" section
2. Upload a PDF file containing requirements
3. View automatic classification results including:
   - Requirement type (UI, Data, Security, etc.)
   - Priority level
   - Complexity assessment
   - Estimated effort
   - Acceptance criteria
   - Dependencies and risks

### 2. Code Generation
1. Go to "Code Generation" section
2. Enter a natural language description
3. Select programming language and framework
4. Generate production-ready code
5. View explanation and download generated files

### 3. Bug Detection & Fixing
1. Navigate to "Bug Fixing" section
2. Paste your code for analysis
3. Select programming language
4. Review identified bugs and fixes
5. Get detailed explanations of issues

### 4. Test Generation
1. Go to "Test Generation" section
2. Input source code
3. Choose test type (unit, integration, performance)
4. Select testing framework
5. Generate comprehensive test cases

### 5. Code Summarization
1. Navigate to "Documentation" section
2. Paste code for analysis
3. Choose summary type
4. Get detailed documentation and complexity analysis

### 6. AI Chatbot
1. Use the floating chatbot icon
2. Ask questions about SDLC processes
3. Get AI-powered guidance and suggestions

## 🔧 Configuration

### Environment Variables
Create a `.env` file in the backend directory:
```env
# Database
DATABASE_URL=sqlite:///./database/smartsdlc.db

# Storage
STORAGE_PATH=./storage
MAX_FILE_SIZE=10485760  # 10MB

# Session
SESSION_TIMEOUT=86400  # 24 hours

# AI Models
HUGGINGFACE_API_KEY=your_api_key_here
```

### Storage Configuration
- **File Size Limits**: Configurable per file type
- **Storage Paths**: Customizable storage directories
- **Cleanup Policies**: Automatic cleanup of temporary files
- **Backup**: Database and file backup recommendations

## 🛠️ Development

### Adding New Features
1. Create new router in `backend/routers/`
2. Add database models in `backend/models.py`
3. Update storage utilities in `backend/storage.py`
4. Add frontend interface in `frontend/`
5. Update API documentation

### Database Migrations
```bash
# Create new migration
alembic revision --autogenerate -m "Description"

# Apply migrations
alembic upgrade head
```

### Testing
```bash
# Run backend tests
cd backend
python -m pytest

# Run frontend tests
cd frontend
npm test
```

## 📊 Monitoring & Maintenance

### Health Checks
- **Backend Health**: `GET /health`
- **Storage Status**: `GET /storage/status`
- **Session Status**: `GET /sessions/status`

### Maintenance Tasks
- **Database Cleanup**: Automatic cleanup of expired sessions
- **File Cleanup**: Automatic cleanup of temporary files
- **Storage Monitoring**: Track storage usage and performance

### Backup Recommendations
- **Database**: Regular SQLite database backups
- **Files**: Backup storage directory
- **Configuration**: Backup environment files

## 🔒 Security Features

### Data Protection
- **File Validation**: Type and size validation
- **Content Hashing**: MD5 hashing for file integrity
- **Session Security**: Secure session management
- **Input Sanitization**: XSS and injection protection

### Access Control
- **User Sessions**: Session-based authentication
- **File Access**: Controlled file access permissions
- **API Security**: Rate limiting and validation

## 🚀 Deployment

### Production Setup
1. **Environment**: Use production-grade database (PostgreSQL)
2. **Storage**: Use cloud storage (AWS S3, Azure Blob)
3. **Security**: Enable HTTPS and secure cookies
4. **Monitoring**: Add logging and monitoring
5. **Backup**: Implement automated backup system

### Docker Deployment
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

- **Documentation**: Check the `/docs` endpoint
- **Issues**: Report bugs and feature requests
- **Community**: Join our developer community

## 🔄 Changelog

### Version 2.0.0 - Storage System
- ✅ Added comprehensive file storage system
- ✅ Integrated SQLite database with SQLAlchemy
- ✅ Implemented session management
- ✅ Enhanced API endpoints with storage support
- ✅ Added file upload/download capabilities
- ✅ Implemented automatic cleanup and maintenance
- ✅ Added storage monitoring and health checks

### Version 1.0.0 - Initial Release
- ✅ Basic SDLC automation features
- ✅ AI-powered code generation
- ✅ Bug detection and fixing
- ✅ Test case generation
- ✅ Code summarization
- ✅ AI chatbot assistant

---

**SmartSDLC** - Empowering developers with AI-driven SDLC automation! 🚀 #   s m a r t - s d l c  
 