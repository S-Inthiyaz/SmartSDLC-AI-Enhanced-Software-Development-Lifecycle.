from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from routers import classifier, codegen, bugfix, testgen, summarizer, chatbot
from models import create_tables
from storage import file_storage
from sessions import session_manager
import os

# Create necessary directories
os.makedirs("storage", exist_ok=True)
os.makedirs("database", exist_ok=True)

# Create database tables
create_tables()

app = FastAPI(title="SmartSDLC API", version="1.0.0", description="AI Powered SDLC Automation")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files for serving uploaded/generated files
app.mount("/files", StaticFiles(directory="storage"), name="files")

# Mount frontend static files
app.mount("/static", StaticFiles(directory="../frontend"), name="static")

app.include_router(classifier.router, prefix="/api", tags=["Requirements"])
app.include_router(codegen.router, prefix="/api", tags=["Code Generation"])
app.include_router(bugfix.router, prefix="/api", tags=["Bug Fixing"])
app.include_router(testgen.router, prefix="/api", tags=["Testing"])
app.include_router(summarizer.router, prefix="/api", tags=["Documentation"])
app.include_router(chatbot.router, prefix="/api", tags=["Chatbot"])

@app.get("/")
def root():
    """Serve the main frontend page"""
    return FileResponse("../frontend/index.html")

@app.get("/health")
def health_check():
    return {"status": "healthy", "message": "SmartSDLC API is operational"}

@app.get("/storage/status")
def storage_status():
    """Check storage status and available space"""
    try:
        storage_info = {
            "storage_path": str(file_storage.base_path),
            "uploads_path": str(file_storage.uploads_path),
            "generated_path": str(file_storage.generated_path),
            "temp_path": str(file_storage.temp_path),
            "directories_exist": {
                "uploads": file_storage.uploads_path.exists(),
                "generated": file_storage.generated_path.exists(),
                "temp": file_storage.temp_path.exists()
            }
        }
        return {"status": "ok", "storage": storage_info}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/sessions/status")
def sessions_status():
    """Check session status"""
    try:
        active_sessions = len(session_manager.sessions)
        cleaned = session_manager.cleanup_expired_sessions()
        return {
            "status": "ok",
            "active_sessions": active_sessions,
            "cleaned_sessions": cleaned
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.on_event("startup")
async def startup_event():
    """Initialize storage and cleanup on startup"""
    print("🚀 Starting SmartSDLC API...")
    print("📁 Initializing storage directories...")
    print("🗄️  Database tables created...")
    print("✅ SmartSDLC API ready!")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    print("🛑 Shutting down SmartSDLC API...")
    # Cleanup temporary files
    cleaned = file_storage.cleanup_temp_files()
    print(f"🧹 Cleaned up {cleaned} temporary files")
