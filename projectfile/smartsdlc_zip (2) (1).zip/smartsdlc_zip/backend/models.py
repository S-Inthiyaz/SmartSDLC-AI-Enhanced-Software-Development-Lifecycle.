from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os

# Create database directory if it doesn't exist
os.makedirs("database", exist_ok=True)

# Database setup
SQLALCHEMY_DATABASE_URL = "sqlite:///./database/smartsdlc.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    files = relationship("File", back_populates="owner")
    conversations = relationship("Conversation", back_populates="user")
    sessions = relationship("UserSession", back_populates="user")

class File(Base):
    __tablename__ = "files"
    
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String, index=True)
    original_filename = Column(String)
    file_path = Column(String)
    file_type = Column(String)  # pdf, code, etc.
    file_size = Column(Integer)
    content_hash = Column(String)
    user_id = Column(Integer, ForeignKey("users.id"))
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    processed = Column(Boolean, default=False)
    meta_data = Column(JSON)  # Store additional info like classifications, etc.
    
    # Relationships
    owner = relationship("User", back_populates="files")

class Conversation(Base):
    __tablename__ = "conversations"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    conversation_id = Column(String, index=True)
    title = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    user = relationship("User", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation")

class Message(Base):
    __tablename__ = "messages"
    
    id = Column(Integer, primary_key=True, index=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id"))
    role = Column(String)  # user, assistant
    content = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    meta_data = Column(JSON)  # Store additional info like phase, suggestions, etc.
    
    # Relationships
    conversation = relationship("Conversation", back_populates="messages")

class UserSession(Base):
    __tablename__ = "user_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    session_id = Column(String, unique=True, index=True)
    data = Column(JSON)  # Store session data like preferences, context, etc.
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    user = relationship("User", back_populates="sessions")

class CodeGeneration(Base):
    __tablename__ = "code_generations"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    prompt = Column(Text)
    generated_code = Column(Text)
    language = Column(String)
    framework = Column(String)
    file_path = Column(String)  # Path to saved code file
    created_at = Column(DateTime, default=datetime.utcnow)
    meta_data = Column(JSON)  # Store additional info like tests, explanation, etc.

class BugFix(Base):
    __tablename__ = "bug_fixes"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    original_code = Column(Text)
    fixed_code = Column(Text)
    language = Column(String)
    bugs_found = Column(JSON)
    explanation = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class TestGeneration(Base):
    __tablename__ = "test_generations"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    source_code = Column(Text)
    test_code = Column(Text)
    language = Column(String)
    framework = Column(String)
    test_type = Column(String)  # unit, integration, performance
    coverage_analysis = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class CodeSummary(Base):
    __tablename__ = "code_summaries"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    source_code = Column(Text)
    summary = Column(Text)
    language = Column(String)
    summary_type = Column(String)  # general, technical, documentation
    complexity_analysis = Column(Text)
    documentation = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

# Create all tables
def create_tables():
    Base.metadata.create_all(bind=engine)

# Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close() 