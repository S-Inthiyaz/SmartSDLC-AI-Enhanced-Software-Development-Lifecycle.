from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict
from utils.huggingface import query_watsonx

router = APIRouter()

class BugFixRequest(BaseModel):
    code: str
    language: Optional[str] = "python"
    include_explanation: Optional[bool] = True

class BugFixResponse(BaseModel):
    original_code: str
    fixed_code: str
    bugs_found: List[Dict[str, str]]
    explanation: str
    language: str

@router.post("/fix-bugs")
async def fix_bugs(request: BugFixRequest):
    """
    Detect and fix bugs in code using Watsonx Granite-20B
    """
    try:
        language = request.language or "python"
        
        # First, analyze the code for potential bugs
        analysis_prompt = f"""
        Analyze this {language} code for bugs, errors, and issues. Identify:
        1. Syntax errors
        2. Logic errors
        3. Performance issues
        4. Security vulnerabilities
        5. Best practice violations
        
        Code:
        {request.code}
        
        List all issues found:
        """
        
        analysis = query_watsonx(analysis_prompt)
        
        # Generate fixed code
        fix_prompt = f"""
        Fix all bugs and issues in this {language} code. Return only the corrected code:
        
        Original code with issues:
        {request.code}
        
        Issues to fix:
        {analysis}
        
        Fixed code:
        """
        
        fixed_code = query_watsonx(fix_prompt)
        
        # Generate explanation of fixes
        explanation = ""
        if request.include_explanation:
            explanation_prompt = f"""
            Explain what bugs were fixed in this {language} code. Compare original vs fixed:
            
            Original:
            {request.code}
            
            Fixed:
            {fixed_code}
            
            Explanation of fixes:
            """
            explanation = query_watsonx(explanation_prompt)
        
        # Parse bugs found (simplified parsing)
        bugs_found = []
        if analysis:
            bugs_found = [{"type": "bug", "description": analysis}]
        
        return BugFixResponse(
            original_code=request.code,
            fixed_code=fixed_code,
            bugs_found=bugs_found,
            explanation=explanation,
            language=language
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fixing bugs: {str(e)}")

@router.post("/analyze-code")
async def analyze_code(request: BugFixRequest):
    """
    Analyze code for potential issues without fixing
    """
    try:
        language = request.language or "python"
        
        analysis_prompt = f"""
        Perform a comprehensive code review of this {language} code. Check for:
        
        1. **Syntax Errors**: Invalid syntax, missing semicolons, brackets, etc.
        2. **Logic Errors**: Incorrect algorithms, wrong conditions, infinite loops
        3. **Performance Issues**: Inefficient algorithms, memory leaks, slow operations
        4. **Security Vulnerabilities**: SQL injection, XSS, input validation issues
        5. **Code Quality**: Code style, naming conventions, documentation
        6. **Best Practices**: Language-specific best practices and patterns
        
        Code to analyze:
        {request.code}
        
        Provide a detailed analysis with specific recommendations:
        """
        
        analysis = query_watsonx(analysis_prompt)
        
        return {
            "code": request.code,
            "analysis": analysis,
            "language": language,
            "issues_count": analysis.count("issue") + analysis.count("error") + analysis.count("bug")
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error analyzing code: {str(e)}")

@router.post("/optimize-code")
async def optimize_code(request: BugFixRequest):
    """
    Optimize code for performance and readability
    """
    try:
        language = request.language or "python"
        
        optimization_prompt = f"""
        Optimize this {language} code for:
        1. Performance (faster execution, lower memory usage)
        2. Readability (cleaner code, better structure)
        3. Maintainability (easier to modify and extend)
        4. Best practices for {language}
        
        Original code:
        {request.code}
        
        Optimized code:
        """
        
        optimized_code = query_watsonx(optimization_prompt)
        
        # Generate explanation of optimizations
        explanation_prompt = f"""
        Explain the optimizations made to this {language} code:
        
        Original:
        {request.code}
        
        Optimized:
        {optimized_code}
        
        Optimization explanation:
        """
        
        explanation = query_watsonx(explanation_prompt)
        
        return {
            "original_code": request.code,
            "optimized_code": optimized_code,
            "explanation": explanation,
            "language": language
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error optimizing code: {str(e)}")
