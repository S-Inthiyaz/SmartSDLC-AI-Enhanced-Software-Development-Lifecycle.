from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from utils.huggingface import query_watsonx
import requests

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    conversation_id: str

# In-memory conversation storage
conversations: Dict[str, Dict[str, Any]] = {}

@router.post("/chatbot")
async def chatbot_respond(request: ChatRequest):
    """
    AI Chatbot Assistant
    """
    conversation_id = request.conversation_id or "default"
    if conversation_id not in conversations:
        conversations[conversation_id] = {"history": []}
    
    conversation = conversations[conversation_id]
    
    # Prepare history for the conversational model
    past_user_inputs = [turn["user"] for turn in conversation["history"]]
    generated_responses = [turn["assistant"] for turn in conversation["history"]]
    
    try:
        # Generate response using the new conversational query function
        response_text = query_watsonx(
            user_input=request.message,
            past_user_inputs=past_user_inputs,
            generated_responses=generated_responses
        )
        
        # Update conversation history ONLY on success
        conversation["history"].append({"user": request.message, "assistant": response_text})
        
        return ChatResponse(
            response=response_text,
            conversation_id=conversation_id,
        )
        
    except requests.exceptions.RequestException as e:
        print(f"Hugging Face API Error: {e}")
        error_message = "I'm sorry, I'm having trouble connecting to the AI service. Please try again in a moment."
        return ChatResponse(
            response=error_message,
            conversation_id=conversation_id,
        )
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred in the chatbot.")
