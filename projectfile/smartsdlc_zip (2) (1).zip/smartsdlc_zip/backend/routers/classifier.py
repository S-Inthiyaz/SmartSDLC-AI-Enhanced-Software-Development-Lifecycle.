from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
import fitz  # PyMuPDF
import json
from models import get_db, File as DBFile, User
from storage import file_storage
from sqlalchemy.orm import Session

router = APIRouter()

class ClassificationResult(BaseModel):
    requirement_type: str
    priority: str
    complexity: str
    estimated_effort: str
    description: str
    acceptance_criteria: List[str]
    dependencies: List[str]
    risks: List[str]

class UploadResponse(BaseModel):
    message: str
    file_id: int
    filename: str
    classification: Optional[ClassificationResult] = None

@router.post("/upload", response_model=UploadResponse)
async def upload_requirement(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload and classify a requirement document"""
    try:
        # Validate file type
        if not file.filename or not file.filename.lower().endswith('.pdf'):
            raise HTTPException(status_code=400, detail="Only PDF files are supported")
        
        # Read file content
        content = await file.read()
        
        # Save file using storage system
        file_metadata = file_storage.save_uploaded_file(
            content, 
            file.filename, 
            "pdf"
        )
        
        # Extract text from PDF
        pdf_text = extract_text_from_pdf(content)
        
        # Classify the requirement
        classification = classify_requirement(pdf_text)
        
        # Save to database
        db_file = DBFile(
            filename=file_metadata["filename"],
            original_filename=file_metadata["original_filename"],
            file_path=file_metadata["file_path"],
            file_type=file_metadata["file_type"],
            file_size=file_metadata["file_size"],
            content_hash=file_metadata["content_hash"],
            user_id=None,  # TODO: Add user authentication
            processed=True,
            meta_data=classification.dict()
        )
        
        db.add(db_file)
        db.commit()
        db.refresh(db_file)
        
        return UploadResponse(
            message="File uploaded and classified successfully",
            file_id=int(db_file.id),
            filename=file_metadata["filename"],
            classification=classification
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

@router.get("/files", response_model=List[dict])
async def list_uploaded_files(db: Session = Depends(get_db)):
    """List all uploaded requirement files"""
    try:
        files = db.query(DBFile).filter(DBFile.file_type == "pdf").all()
        return [
            {
                "id": file.id,
                "filename": file.original_filename,
                "uploaded_at": file.uploaded_at.isoformat(),
                "processed": file.processed,
                "classification": file.meta_data
            }
            for file in files
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving files: {str(e)}")

@router.get("/files/{file_id}", response_model=dict)
async def get_file_details(file_id: int, db: Session = Depends(get_db)):
    """Get details of a specific uploaded file"""
    try:
        file = db.query(DBFile).filter(DBFile.id == file_id).first()
        if not file:
            raise HTTPException(status_code=404, detail="File not found")
        
        return {
            "id": file.id,
            "filename": file.original_filename,
            "uploaded_at": file.uploaded_at.isoformat(),
            "processed": file.processed,
            "classification": file.meta_data,
            "file_path": file.file_path
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving file: {str(e)}")

def extract_text_from_pdf(pdf_content: bytes) -> str:
    """Extract text from PDF content"""
    try:
        doc = fitz.open(stream=pdf_content, filetype="pdf")
        text = ""
        for page in doc:
            text += page.get_text()
        doc.close()
        return text
    except Exception as e:
        raise Exception(f"Error extracting text from PDF: {str(e)}")

def classify_requirement(text: str) -> ClassificationResult:
    """Classify requirement based on text content"""
    # This is a simplified classification logic
    # In a real implementation, you would use AI/ML models
    
    # Simple keyword-based classification
    text_lower = text.lower()
    
    # Determine requirement type
    if any(word in text_lower for word in ["user", "interface", "ui", "ux"]):
        req_type = "User Interface"
    elif any(word in text_lower for word in ["database", "data", "storage"]):
        req_type = "Data Management"
    elif any(word in text_lower for word in ["security", "authentication", "authorization"]):
        req_type = "Security"
    elif any(word in text_lower for word in ["performance", "speed", "optimization"]):
        req_type = "Performance"
    else:
        req_type = "Functional"
    
    # Determine priority
    if any(word in text_lower for word in ["critical", "urgent", "must have"]):
        priority = "High"
    elif any(word in text_lower for word in ["important", "should have"]):
        priority = "Medium"
    else:
        priority = "Low"
    
    # Determine complexity
    if len(text) > 1000:
        complexity = "High"
    elif len(text) > 500:
        complexity = "Medium"
    else:
        complexity = "Low"
    
    # Estimate effort
    if complexity == "High":
        effort = "3-5 weeks"
    elif complexity == "Medium":
        effort = "1-3 weeks"
    else:
        effort = "3-5 days"
    
    return ClassificationResult(
        requirement_type=req_type,
        priority=priority,
        complexity=complexity,
        estimated_effort=effort,
        description=text[:200] + "..." if len(text) > 200 else text,
        acceptance_criteria=["Criteria 1", "Criteria 2", "Criteria 3"],
        dependencies=["Dependency 1", "Dependency 2"],
        risks=["Risk 1", "Risk 2"]
    )
