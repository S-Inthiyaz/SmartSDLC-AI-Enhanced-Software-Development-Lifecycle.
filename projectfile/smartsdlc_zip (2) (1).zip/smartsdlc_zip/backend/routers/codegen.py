from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, List
import json
from models import get_db, CodeGeneration
from storage import file_storage
from sqlalchemy.orm import Session

router = APIRouter()

class CodeGenerationRequest(BaseModel):
    prompt: str
    language: str
    framework: Optional[str] = None
    user_id: Optional[int] = None

class CodeGenerationResponse(BaseModel):
    generated_code: str
    explanation: str
    file_path: Optional[str] = None
    generation_id: Optional[int] = None

@router.post("/generate", response_model=CodeGenerationResponse)
async def generate_code(
    request: CodeGenerationRequest,
    db: Session = Depends(get_db)
):
    """Generate code based on prompt"""
    try:
        # Generate code using AI (simplified for now)
        generated_code = generate_code_from_prompt(request.prompt, request.language, request.framework)
        explanation = f"Generated {request.language} code for: {request.prompt}"
        
        # Save generated code to file
        file_metadata = file_storage.save_generated_code(
            code=generated_code,
            language=request.language,
            framework=request.framework,
            user_id=request.user_id
        )
        
        # Save to database
        db_generation = CodeGeneration(
            user_id=request.user_id,
            prompt=request.prompt,
            generated_code=generated_code,
            language=request.language,
            framework=request.framework,
            file_path=file_metadata["file_path"],
            meta_data={
                "explanation": explanation,
                "generated_at": file_metadata["generated_at"]
            }
        )
        
        db.add(db_generation)
        db.commit()
        db.refresh(db_generation)
        
        return CodeGenerationResponse(
            generated_code=generated_code,
            explanation=explanation,
            file_path=file_metadata["file_path"],
            generation_id=int(db_generation.id)
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating code: {str(e)}")

@router.get("/history", response_model=List[dict])
async def get_generation_history(db: Session = Depends(get_db)):
    """Get code generation history"""
    try:
        generations = db.query(CodeGeneration).order_by(CodeGeneration.created_at.desc()).all()
        return [
            {
                "id": gen.id,
                "prompt": gen.prompt,
                "language": gen.language,
                "framework": gen.framework,
                "created_at": gen.created_at.isoformat(),
                "file_path": gen.file_path
            }
            for gen in generations
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving history: {str(e)}")

@router.get("/history/{generation_id}", response_model=dict)
async def get_generation_details(generation_id: int, db: Session = Depends(get_db)):
    """Get details of a specific code generation"""
    try:
        generation = db.query(CodeGeneration).filter(CodeGeneration.id == generation_id).first()
        if not generation:
            raise HTTPException(status_code=404, detail="Generation not found")
        
        return {
            "id": generation.id,
            "prompt": generation.prompt,
            "generated_code": generation.generated_code,
            "language": generation.language,
            "framework": generation.framework,
            "created_at": generation.created_at.isoformat(),
            "file_path": generation.file_path,
            "metadata": generation.meta_data
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving generation: {str(e)}")

def generate_code_from_prompt(prompt: str, language: str, framework: Optional[str] = None) -> str:
    """Generate code based on prompt and language"""
    # This is a simplified code generation
    # In a real implementation, you would use AI models
    
    if language.lower() == "python":
        if framework and "flask" in framework.lower():
            return f'''from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({{"message": "Hello World"}})

@app.route('/api/data', methods=['GET'])
def get_data():
    return jsonify({{"data": "Sample data"}})

if __name__ == '__main__':
    app.run(debug=True)
'''
        else:
            return f'''def main():
    """
    {prompt}
    """
    print("Hello World")
    
if __name__ == "__main__":
    main()
'''
    
    elif language.lower() == "javascript":
        if framework and "express" in framework.lower():
            return f'''const express = require('express');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {{
    res.json({{ message: 'Hello World' }});
}});

app.get('/api/data', (req, res) => {{
    res.json({{ data: 'Sample data' }});
}});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {{
    console.log(`Server running on port ${{PORT}}`);
}});
'''
        else:
            return f'''// {prompt}
function main() {{
    console.log("Hello World");
}}

main();
'''
    
    else:
        return f'''// Generated {language} code
// {prompt}
// TODO: Implement functionality
'''
