from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict
from utils.huggingface import query_watsonx

router = APIRouter()

class SummarizerRequest(BaseModel):
    code: str
    language: Optional[str] = "python"
    summary_type: Optional[str] = "general"  # general, technical, documentation, readme

class SummarizerResponse(BaseModel):
    summary: str
    language: str
    summary_type: str
    complexity_analysis: str
    documentation: str

@router.post("/summarize-code")
async def summarize_code(request: SummarizerRequest):
    """
    Generate comprehensive code summaries using Watsonx Granite-20B
    """
    try:
        language = request.language or "python"
        summary_type = request.summary_type or "general"
        
        # Generate main summary
        summary_prompt = f"""
        Provide a comprehensive summary of this {language} code:
        
        Code:
        {request.code}
        
        Include:
        1. What the code does (purpose and functionality)
        2. Main components and their roles
        3. Key algorithms or patterns used
        4. Input/output specifications
        5. Dependencies and requirements
        6. Usage examples if applicable
        
        Summary:
        """
        
        summary = query_watsonx(summary_prompt)
        
        # Generate complexity analysis
        complexity_prompt = f"""
        Analyze the complexity and structure of this {language} code:
        
        Code:
        {request.code}
        
        Provide:
        1. Time complexity analysis
        2. Space complexity analysis
        3. Code structure assessment
        4. Maintainability score
        5. Potential improvements
        6. Best practices followed/missing
        
        Complexity Analysis:
        """
        
        complexity_analysis = query_watsonx(complexity_prompt)
        
        # Generate documentation
        doc_prompt = f"""
        Generate comprehensive documentation for this {language} code:
        
        Code:
        {request.code}
        
        Create:
        1. Function/method documentation with parameters
        2. Class documentation if applicable
        3. Usage examples
        4. Error handling documentation
        5. Performance considerations
        6. Security considerations
        
        Documentation:
        """
        
        documentation = query_watsonx(doc_prompt)
        
        return SummarizerResponse(
            summary=summary,
            language=language,
            summary_type=summary_type,
            complexity_analysis=complexity_analysis,
            documentation=documentation
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error summarizing code: {str(e)}")

@router.post("/generate-readme")
async def generate_readme(request: SummarizerRequest):
    """
    Generate README documentation for code projects
    """
    try:
        language = request.language or "python"
        
        readme_prompt = f"""
        Generate a comprehensive README.md file for this {language} project:
        
        Code:
        {request.code}
        
        Include:
        1. Project title and description
        2. Features and capabilities
        3. Installation instructions
        4. Usage examples
        5. API documentation (if applicable)
        6. Configuration options
        7. Dependencies and requirements
        8. Contributing guidelines
        9. License information
        10. Troubleshooting section
        
        Format as proper Markdown:
        """
        
        readme_content = query_watsonx(readme_prompt)
        
        return {
            "readme": readme_content,
            "language": language,
            "format": "markdown"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating README: {str(e)}")

@router.post("/generate-api-docs")
async def generate_api_docs(request: SummarizerRequest):
    """
    Generate API documentation for endpoints and functions
    """
    try:
        language = request.language or "python"
        
        api_docs_prompt = f"""
        Generate comprehensive API documentation for this {language} code:
        
        Code:
        {request.code}
        
        Create documentation including:
        1. Endpoint/function descriptions
        2. Request/response formats
        3. Parameter specifications
        4. Authentication requirements
        5. Error codes and messages
        6. Rate limiting information
        7. Example requests and responses
        8. SDK examples if applicable
        
        API Documentation:
        """
        
        api_docs = query_watsonx(api_docs_prompt)
        
        return {
            "api_documentation": api_docs,
            "language": language,
            "format": "markdown"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating API docs: {str(e)}")

@router.post("/explain-algorithm")
async def explain_algorithm(request: SummarizerRequest):
    """
    Explain algorithms and complex logic in code
    """
    try:
        language = request.language or "python"
        
        algorithm_prompt = f"""
        Explain the algorithms and complex logic in this {language} code:
        
        Code:
        {request.code}
        
        Provide:
        1. Step-by-step algorithm explanation
        2. Mathematical concepts involved
        3. Data structures used
        4. Optimization techniques
        5. Alternative approaches
        6. Performance characteristics
        7. Real-world applications
        
        Algorithm Explanation:
        """
        
        algorithm_explanation = query_watsonx(algorithm_prompt)
        
        return {
            "algorithm_explanation": algorithm_explanation,
            "language": language,
            "complexity": "Detailed analysis provided"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error explaining algorithm: {str(e)}")

@router.post("/code-review")
async def code_review(request: SummarizerRequest):
    """
    Perform a comprehensive code review
    """
    try:
        language = request.language or "python"
        
        review_prompt = f"""
        Perform a comprehensive code review of this {language} code:
        
        Code:
        {request.code}
        
        Review aspects:
        1. **Code Quality**: Readability, maintainability, style
        2. **Performance**: Efficiency, bottlenecks, optimizations
        3. **Security**: Vulnerabilities, best practices
        4. **Testing**: Testability, coverage needs
        5. **Architecture**: Design patterns, structure
        6. **Documentation**: Comments, docstrings, clarity
        7. **Error Handling**: Exception management
        8. **Best Practices**: Language-specific conventions
        
        Provide specific recommendations and improvements.
        
        Code Review:
        """
        
        code_review = query_watsonx(review_prompt)
        
        return {
            "code_review": code_review,
            "language": language,
            "review_score": "85/100",  # Placeholder
            "critical_issues": [],
            "suggestions": []
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error performing code review: {str(e)}")
