from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict
from utils.huggingface import query_watsonx

router = APIRouter()

class TestGenerationRequest(BaseModel):
    code: Optional[str] = None
    requirements: Optional[str] = None
    language: Optional[str] = "python"
    framework: Optional[str] = None
    test_type: Optional[str] = "unit"  # unit, integration, e2e

class TestGenerationResponse(BaseModel):
    test_code: str
    language: str
    framework: str
    test_type: str
    coverage_analysis: str
    test_cases: List[Dict[str, str]]

@router.post("/generate-tests")
async def generate_tests(request: TestGenerationRequest):
    """
    Generate comprehensive test cases using Watsonx Granite-20B
    """
    try:
        language = request.language or "python"
        test_type = request.test_type or "unit"
        
        # Determine testing framework based on language
        framework_map = {
            "python": "pytest" if not request.framework else request.framework,
            "javascript": "jest" if not request.framework else request.framework,
            "typescript": "jest" if not request.framework else request.framework,
            "java": "junit" if not request.framework else request.framework,
            "go": "testing" if not request.framework else request.framework,
            "rust": "built-in" if not request.framework else request.framework
        }
        
        framework = framework_map.get(language, "pytest")
        
        if request.code:
            # Generate tests from source code
            prompt = f"""
            Generate comprehensive {test_type} tests for this {language} code using {framework}:
            
            Source Code:
            {request.code}
            
            Requirements:
            1. Test all functions/methods
            2. Include edge cases and error conditions
            3. Use proper assertions and mocking where needed
            4. Follow {framework} best practices
            5. Include test descriptions and comments
            6. Test both positive and negative scenarios
            
            Test Code:
            """
        elif request.requirements:
            # Generate tests from requirements
            prompt = f"""
            Generate {test_type} tests based on these requirements using {language} and {framework}:
            
            Requirements:
            {request.requirements}
            
            Requirements:
            1. Create test cases that validate each requirement
            2. Include positive and negative test scenarios
            3. Test edge cases and boundary conditions
            4. Use proper test structure and naming
            5. Include setup and teardown if needed
            
            Test Code:
            """
        else:
            raise HTTPException(status_code=400, detail="Either code or requirements must be provided")
        
        test_code = query_watsonx(prompt)
        
        # Generate coverage analysis
        coverage_prompt = f"""
        Analyze the test coverage for this {language} code and tests:
        
        Code:
        {request.code or "N/A"}
        
        Tests:
        {test_code}
        
        Provide a coverage analysis including:
        1. What functionality is covered
        2. What might be missing
        3. Suggestions for additional test cases
        4. Overall test quality assessment
        
        Coverage Analysis:
        """
        
        coverage_analysis = query_watsonx(coverage_prompt)
        
        # Extract test cases (simplified parsing)
        test_cases = [{"name": f"Test Case {i+1}", "description": "Generated test case"} 
                     for i in range(test_code.count("def test_") or test_code.count("test(") or 3)]
        
        return TestGenerationResponse(
            test_code=test_code,
            language=language,
            framework=framework,
            test_type=test_type,
            coverage_analysis=coverage_analysis,
            test_cases=test_cases
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating tests: {str(e)}")

@router.post("/generate-integration-tests")
async def generate_integration_tests(request: TestGenerationRequest):
    """
    Generate integration tests for API endpoints or component interactions
    """
    try:
        language = request.language or "python"
        framework = request.framework or "pytest"
        
        prompt = f"""
        Generate integration tests for this {language} code using {framework}:
        
        Code:
        {request.code}
        
        Focus on:
        1. API endpoint testing (if applicable)
        2. Database interactions
        3. External service integrations
        4. Component interactions
        5. End-to-end workflows
        6. Error handling and edge cases
        
        Use appropriate tools:
        - Python: pytest, requests, unittest.mock
        - JavaScript: jest, supertest, nock
        - Java: JUnit, Mockito, TestContainers
        - Go: testing, httptest, testify
        
        Integration Tests:
        """
        
        integration_tests = query_watsonx(prompt)
        
        return {
            "integration_tests": integration_tests,
            "language": language,
            "framework": framework,
            "test_type": "integration"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating integration tests: {str(e)}")

@router.post("/generate-performance-tests")
async def generate_performance_tests(request: TestGenerationRequest):
    """
    Generate performance and load tests
    """
    try:
        language = request.language or "python"
        
        prompt = f"""
        Generate performance tests for this {language} code:
        
        Code:
        {request.code}
        
        Include:
        1. Load testing scenarios
        2. Stress testing
        3. Performance benchmarks
        4. Memory usage tests
        5. Response time measurements
        
        Use appropriate tools:
        - Python: pytest-benchmark, locust, asyncio
        - JavaScript: k6, artillery, autocannon
        - Java: JMeter, Gatling, JUnit
        - Go: testing, benchmark, vegeta
        
        Performance Tests:
        """
        
        performance_tests = query_watsonx(prompt)
        
        return {
            "performance_tests": performance_tests,
            "language": language,
            "test_type": "performance"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating performance tests: {str(e)}")

@router.post("/analyze-test-coverage")
async def analyze_test_coverage(request: TestGenerationRequest):
    """
    Analyze existing test coverage and suggest improvements
    """
    try:
        language = request.language or "python"
        
        prompt = f"""
        Analyze the test coverage for this {language} code and suggest improvements:
        
        Code:
        {request.code}
        
        Current Tests:
        {request.requirements or "No tests provided"}
        
        Provide:
        1. Coverage percentage estimation
        2. Missing test scenarios
        3. Critical paths not tested
        4. Suggestions for additional test types
        5. Test quality recommendations
        
        Coverage Analysis:
        """
        
        coverage_analysis = query_watsonx(prompt)
        
        return {
            "coverage_analysis": coverage_analysis,
            "language": language,
            "estimated_coverage": "85%",  # Placeholder
            "missing_scenarios": ["edge cases", "error conditions"],
            "recommendations": ["Add integration tests", "Include performance tests"]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error analyzing test coverage: {str(e)}")
