import json
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from fastapi import Request, Response
from fastapi.responses import JSONResponse

class SessionManager:
    def __init__(self):
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.session_timeout = timedelta(hours=24)  # 24 hours
    
    def create_session(self, user_id: Optional[int] = None, data: Optional[Dict[str, Any]] = None) -> str:
        """Create a new session"""
        session_id = str(uuid.uuid4())
        session_data = {
            "user_id": user_id,
            "created_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + self.session_timeout).isoformat(),
            "data": data or {}
        }
        self.sessions[session_id] = session_data
        return session_id
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session data"""
        if session_id not in self.sessions:
            return None
        
        session = self.sessions[session_id]
        
        # Check if session has expired
        expires_at = datetime.fromisoformat(session["expires_at"])
        if datetime.now() > expires_at:
            self.delete_session(session_id)
            return None
        
        return session
    
    def update_session(self, session_id: str, data: Dict[str, Any]) -> bool:
        """Update session data"""
        if session_id not in self.sessions:
            return False
        
        self.sessions[session_id]["data"].update(data)
        self.sessions[session_id]["expires_at"] = (datetime.now() + self.session_timeout).isoformat()
        return True
    
    def delete_session(self, session_id: str) -> bool:
        """Delete a session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False
    
    def cleanup_expired_sessions(self) -> int:
        """Clean up expired sessions"""
        current_time = datetime.now()
        expired_sessions = []
        
        for session_id, session in self.sessions.items():
            expires_at = datetime.fromisoformat(session["expires_at"])
            if current_time > expires_at:
                expired_sessions.append(session_id)
        
        for session_id in expired_sessions:
            del self.sessions[session_id]
        
        return len(expired_sessions)
    
    def get_user_sessions(self, user_id: int) -> Dict[str, Dict[str, Any]]:
        """Get all sessions for a user"""
        user_sessions = {}
        for session_id, session in self.sessions.items():
            if session.get("user_id") == user_id:
                user_sessions[session_id] = session
        return user_sessions

# Global session manager
session_manager = SessionManager()

class SessionMiddleware:
    """Middleware to handle sessions"""
    
    def __init__(self, app):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            request = Request(scope, receive)
            
            # Get session ID from cookies
            session_id = request.cookies.get("session_id")
            
            if session_id:
                session = session_manager.get_session(session_id)
                if session:
                    # Add session to request state
                    scope["session"] = session
                else:
                    # Invalid session, create new one
                    session_id = session_manager.create_session()
                    scope["session"] = session_manager.get_session(session_id)
            else:
                # No session, create new one
                session_id = session_manager.create_session()
                scope["session"] = session_manager.get_session(session_id)
            
            # Store session_id for response
            scope["session_id"] = session_id
        
        await self.app(scope, receive, send)

def get_session_data(request: Request) -> Dict[str, Any]:
    """Get session data from request"""
    return getattr(request.state, "session", {}).get("data", {})

def set_session_data(request: Request, data: Dict[str, Any]) -> bool:
    """Set session data"""
    session_id = getattr(request.state, "session_id", None)
    if session_id:
        return session_manager.update_session(session_id, data)
    return False

def create_session_response(data: Dict[str, Any], session_id: str) -> JSONResponse:
    """Create response with session cookie"""
    response = JSONResponse(content=data)
    response.set_cookie(
        key="session_id",
        value=session_id,
        max_age=86400,  # 24 hours
        httponly=True,
        secure=False,  # Set to True in production with HTTPS
        samesite="lax"
    )
    return response 