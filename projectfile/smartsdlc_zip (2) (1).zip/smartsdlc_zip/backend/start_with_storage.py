#!/usr/bin/env python3
"""
SmartSDLC Startup Script with Storage
Initializes database, storage, and starts the FastAPI server
"""

import os
import sys
import subprocess
from pathlib import Path

def create_directories():
    """Create necessary directories"""
    directories = [
        "storage",
        "storage/uploads",
        "storage/uploads/pdfs",
        "storage/uploads/images", 
        "storage/uploads/documents",
        "storage/generated",
        "storage/generated/code",
        "storage/generated/tests",
        "storage/generated/docs",
        "storage/temp",
        "database"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"✅ Created directory: {directory}")

def install_dependencies():
    """Install required dependencies"""
    try:
        print("📦 Installing dependencies...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependencies installed successfully")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing dependencies: {e}")
        return False
    return True

def initialize_database():
    """Initialize database tables"""
    try:
        print("🗄️  Initializing database...")
        from models import create_tables
        create_tables()
        print("✅ Database initialized successfully")
        return True
    except Exception as e:
        print(f"❌ Error initializing database: {e}")
        return False

def check_storage():
    """Check storage system"""
    try:
        print("📁 Checking storage system...")
        from storage import file_storage
        
        # Test storage paths
        storage_info = {
            "storage_path": str(file_storage.base_path),
            "uploads_path": str(file_storage.uploads_path),
            "generated_path": str(file_storage.generated_path),
            "temp_path": str(file_storage.temp_path)
        }
        
        for name, path in storage_info.items():
            if Path(path).exists():
                print(f"✅ {name}: {path}")
            else:
                print(f"❌ {name}: {path} (not found)")
        
        return True
    except Exception as e:
        print(f"❌ Error checking storage: {e}")
        return False

def start_server():
    """Start the FastAPI server"""
    try:
        print("🚀 Starting SmartSDLC API server...")
        print("📍 Server will be available at: http://127.0.0.1:8000")
        print("📚 API documentation at: http://127.0.0.1:8000/docs")
        print("🛑 Press Ctrl+C to stop the server")
        print("-" * 50)
        
        # Start uvicorn server
        subprocess.run([
            sys.executable, "-m", "uvicorn", 
            "main:app", 
            "--reload", 
            "--host", "127.0.0.1", 
            "--port", "8000"
        ])
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Error starting server: {e}")

def main():
    """Main startup function"""
    print("=" * 60)
    print("🚀 SmartSDLC Startup with Storage System")
    print("=" * 60)
    
    # Change to backend directory
    backend_dir = Path(__file__).parent
    os.chdir(backend_dir)
    print(f"📂 Working directory: {os.getcwd()}")
    
    # Create directories
    print("\n📁 Creating directories...")
    create_directories()
    
    # Install dependencies
    print("\n📦 Checking dependencies...")
    if not install_dependencies():
        print("❌ Failed to install dependencies")
        return
    
    # Initialize database
    print("\n🗄️  Setting up database...")
    if not initialize_database():
        print("❌ Failed to initialize database")
        return
    
    # Check storage
    print("\n📁 Setting up storage...")
    if not check_storage():
        print("❌ Failed to check storage")
        return
    
    print("\n" + "=" * 60)
    print("✅ SmartSDLC is ready!")
    print("=" * 60)
    
    # Start server
    start_server()

if __name__ == "__main__":
    main() 