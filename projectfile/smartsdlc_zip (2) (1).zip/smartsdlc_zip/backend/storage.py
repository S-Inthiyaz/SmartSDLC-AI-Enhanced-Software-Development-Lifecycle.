import os
import hashlib
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any
import aiofiles
import json

class FileStorage:
    def __init__(self, base_path: str = "storage"):
        self.base_path = Path(base_path)
        self.uploads_path = self.base_path / "uploads"
        self.generated_path = self.base_path / "generated"
        self.temp_path = self.base_path / "temp"
        
        # Create directories
        self._create_directories()
    
    def _create_directories(self):
        """Create necessary directories"""
        self.uploads_path.mkdir(parents=True, exist_ok=True)
        self.generated_path.mkdir(parents=True, exist_ok=True)
        self.temp_path.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        (self.uploads_path / "pdfs").mkdir(exist_ok=True)
        (self.uploads_path / "images").mkdir(exist_ok=True)
        (self.uploads_path / "documents").mkdir(exist_ok=True)
        (self.generated_path / "code").mkdir(exist_ok=True)
        (self.generated_path / "tests").mkdir(exist_ok=True)
        (self.generated_path / "docs").mkdir(exist_ok=True)
    
    def save_uploaded_file(self, file_content: bytes, original_filename: str, file_type: str = "pdf") -> Dict[str, Any]:
        """Save an uploaded file and return metadata"""
        # Generate unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_hash = hashlib.md5(file_content).hexdigest()
        file_extension = Path(original_filename).suffix
        
        # Create filename
        filename = f"{timestamp}_{file_hash}{file_extension}"
        
        # Determine save path based on file type
        if file_type.lower() == "pdf":
            save_path = self.uploads_path / "pdfs" / filename
        elif file_type.lower() in ["jpg", "jpeg", "png", "gif"]:
            save_path = self.uploads_path / "images" / filename
        else:
            save_path = self.uploads_path / "documents" / filename
        
        # Save file
        with open(save_path, "wb") as f:
            f.write(file_content)
        
        # Return metadata
        return {
            "filename": filename,
            "original_filename": original_filename,
            "file_path": str(save_path),
            "file_type": file_type,
            "file_size": len(file_content),
            "content_hash": file_hash,
            "uploaded_at": datetime.now().isoformat()
        }
    
    def save_generated_code(self, code: str, language: str, framework: Optional[str] = None, user_id: Optional[int] = None) -> Dict[str, Any]:
        """Save generated code to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Determine file extension
        extensions = {
            "python": ".py",
            "javascript": ".js",
            "typescript": ".ts",
            "java": ".java",
            "go": ".go",
            "rust": ".rs",
            "cpp": ".cpp",
            "c": ".c"
        }
        
        extension = extensions.get(language.lower(), ".txt")
        filename = f"generated_{timestamp}{extension}"
        save_path = self.generated_path / "code" / filename
        
        # Save code
        with open(save_path, "w", encoding="utf-8") as f:
            f.write(code)
        
        return {
            "filename": filename,
            "file_path": str(save_path),
            "language": language,
            "framework": framework,
            "generated_at": datetime.now().isoformat(),
            "user_id": user_id
        }
    
    def save_generated_tests(self, test_code: str, language: str, framework: str, test_type: str, user_id: Optional[int] = None) -> Dict[str, Any]:
        """Save generated test code"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Determine file extension
        extensions = {
            "python": ".py",
            "javascript": ".js",
            "typescript": ".ts",
            "java": ".java",
            "go": ".go"
        }
        
        extension = extensions.get(language.lower(), ".txt")
        filename = f"tests_{test_type}_{timestamp}{extension}"
        save_path = self.generated_path / "tests" / filename
        
        # Save test code
        with open(save_path, "w", encoding="utf-8") as f:
            f.write(test_code)
        
        return {
            "filename": filename,
            "file_path": str(save_path),
            "language": language,
            "framework": framework,
            "test_type": test_type,
            "generated_at": datetime.now().isoformat(),
            "user_id": user_id
        }
    
    def save_documentation(self, content: str, doc_type: str, language: Optional[str] = None, user_id: Optional[int] = None) -> Dict[str, Any]:
        """Save generated documentation"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Determine file extension
        extensions = {
            "readme": ".md",
            "api_docs": ".md",
            "summary": ".md",
            "documentation": ".md"
        }
        
        extension = extensions.get(doc_type.lower(), ".txt")
        filename = f"{doc_type}_{timestamp}{extension}"
        save_path = self.generated_path / "docs" / filename
        
        # Save documentation
        with open(save_path, "w", encoding="utf-8") as f:
            f.write(content)
        
        return {
            "filename": filename,
            "file_path": str(save_path),
            "doc_type": doc_type,
            "language": language,
            "generated_at": datetime.now().isoformat(),
            "user_id": user_id
        }
    
    def get_file_content(self, file_path: str) -> Optional[str]:
        """Get file content as string"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            return None
    
    def get_file_bytes(self, file_path: str) -> Optional[bytes]:
        """Get file content as bytes"""
        try:
            with open(file_path, "rb") as f:
                return f.read()
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            return None
    
    def delete_file(self, file_path: str) -> bool:
        """Delete a file"""
        try:
            os.remove(file_path)
            return True
        except Exception as e:
            print(f"Error deleting file {file_path}: {e}")
            return False
    
    def list_user_files(self, user_id: int, file_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """List files for a specific user"""
        files = []
        
        # This would typically query the database
        # For now, we'll return a placeholder
        return files
    
    def cleanup_temp_files(self, max_age_hours: int = 24) -> int:
        """Clean up temporary files older than specified hours"""
        cleaned_count = 0
        cutoff_time = datetime.now().timestamp() - (max_age_hours * 3600)
        
        for file_path in self.temp_path.rglob("*"):
            if file_path.is_file():
                if file_path.stat().st_mtime < cutoff_time:
                    try:
                        file_path.unlink()
                        cleaned_count += 1
                    except Exception as e:
                        print(f"Error cleaning up {file_path}: {e}")
        
        return cleaned_count

# Global file storage instance
file_storage = FileStorage() 