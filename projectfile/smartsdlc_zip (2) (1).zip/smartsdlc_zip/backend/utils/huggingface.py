import os
import requests
from dotenv import load_dotenv
import pathlib

# --- Load Environment Variables ---
project_root = pathlib.Path(__file__).parent.parent.parent
dotenv_path = project_root / 'smartsdlc.env'
if dotenv_path.exists():
    load_dotenv(dotenv_path=dotenv_path)

# --- Hugging Face API Configuration ---
MODEL_ID = os.getenv("HF_MODEL_ID", "microsoft/DialoGPT-medium")
HF_API_KEY = os.getenv("HF_API_KEY")
API_URL = f"https://api-inference.huggingface.co/models/{MODEL_ID}"
HEADERS = {"Authorization": f"Bearer {HF_API_KEY}"}

def query_conversational_model(user_input: str, past_user_inputs: list[str], generated_responses: list[str]) -> str:
    """
    Queries a conversational model on the HuggingFace Inference API.
    """
    payload = {
        "inputs": {
            "past_user_inputs": past_user_inputs,
            "generated_responses": generated_responses,
            "text": user_input,
        },
        "parameters": {
            "max_new_tokens": 120,
            "temperature": 0.8,
            "top_p": 0.9,
            "do_sample": True,
        },
        "options": {
            "wait_for_model": True  # Crucial for models that might not be instantly ready
        }
    }
    
    response = requests.post(API_URL, headers=HEADERS, json=payload, timeout=60)
    response.raise_for_status()  # Will raise an error for 4xx/5xx responses
    result = response.json()
    
    # The response contains the full conversation history, we only need the latest response
    return result.get("generated_text", "").strip()

# Keep a simple alias for the chatbot to call
query_watsonx = query_conversational_model
