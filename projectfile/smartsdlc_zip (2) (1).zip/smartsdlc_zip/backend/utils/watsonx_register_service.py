import requests
import json

API_KEY = "your_api_key"
SPACE_ID = "816ae183-dcd1-4fbc-ab06-4acfc346eccc"
CLUSTER_URL = "https://eu-de.ml.cloud.ibm.com"  # changed region to eu-de
SOFTWARE_SPEC_ID = "45f12dfe-aa78-5b8d-9f38-0ee223c47309"
VERSION = "2024-10-17"

# You typically get the bearer token from IAM
def register_ai_service():
    token = "Bearer eyJraWQiOiIyMDE5MDcyNCIsImFsZyI6IlJTMjU2In0.eyJpYW1faWQiOiJJQk1pZC02QTEwMDBCMDc3IiwiaWQiOiJJQk1pZC02QTEwMDBCMDc3IiwicmVhbG1pZCI6IklCTWlkIiwianRpIjoiNjg3ZWYyYWYtYmY3ZS00ZDk2LWJlMGItODc5MWM1MjdhMjZjIiwiaWRlbnRpZmllciI6IjZBMTAwMEIwNzciLCJnaXZlbl9uYW1lIjoiTWVocnVkZGluIiwiZmFtaWx5X25hbWUiOiJTaGFpayIsIm5hbWUiOiJNZWhydWRkaW4gU2hhaWsiLCJlbWFpbCI6InNoYWlrbWVocnU3ODZAZ21haWwuY29tIiwic3ViIjoic2hhaWttZWhydTc4NkBnbWFpbC5jb20iLCJhdXRobiI6eyJzdWIiOiJzaGFpa21laHJ1Nzg2QGdtYWlsLmNvbSIsImlhbV9pZCI6IklCTWlkLTZBMTAwMEIwNzciLCJuYW1lIjoiTWVocnVkZGluIFNoYWlrIiwiZ2l2ZW5fbmFtZSI6Ik1laHJ1ZGRpbiIsImZhbWlseV9uYW1lIjoiU2hhaWsiLCJlbWFpbCI6InNoYWlrbWVocnU3ODZAZ21haWwuY29tIn0sImFjY291bnQiOnsidmFsaWQiOnRydWUsImJzcyI6ImQ5ZTIxNjUwYmZiNzQzOGNhNjY0NWU3ZDYxOTAxNzgzIiwiZnJvemVuIjp0cnVlfSwiaWF0IjoxNzUwNjU3ODk4LCJleHAiOjE3NTA2NjE0OTgsImlzcyI6Imh0dHBzOi8vaWFtLmNsb3VkLmlibS5jb20vaWRlbnRpdHkiLCJncmFudF90eXBlIjoidXJuOmlibTpwYXJhbXM6b2F1dGg6Z3JhbnQtdHlwZTphcGlrZXkiLCJzY29wZSI6ImlibSBvcGVuaWQiLCJjbGllbnRfaWQiOiJkZWZhdWx0IiwiYWNyIjoxLCJhbXIiOlsicHdkIl19.KUYiAYQhVimlitGDBKlkmCYRTIdp1zhNeSM28wBsfbQgQASwvZc2uWIwSpD5V7akP8qm7WbU6IiirQL_YxlE4slQjDJ-AikG2uFAX7JznPVeFg1YRbpBJ17OU-nHMH_tyJdEH-n3DuFaIM-RQcDfiHWFUgn_3Pt2OVH0y7eFtBHsWIb1Bpxl4uSgHonRlTFJDkGVJRgL_J0KYgWp1YNY2yYiFRuFSGK0pXHFkzv26CHAKFQVOI0KINreFmffONpHOs6KtIMhFHJ3ketFTsk3rRbg6iIeDQG3ZnI8wh1LIx5uoY-QvA_hpExzEpRBaqxBgtcl7kZezublnUiC2E4dLA"  # use actual IAM token here

    url = f"{CLUSTER_URL}/ml/v4/ai_services?version={VERSION}"

    payload = {
        "name": "ai-service-1",
        "space_id": SPACE_ID,
        "software_spec": {
            "id": SOFTWARE_SPEC_ID
        },
        "documentation": {
            "request": {
                "application/json": {
                    "$schema": "http://json-schema.org/draft-07/schema#",
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "parameters": {
                            "properties": {
                                "max_new_tokens": {"type": "integer"},
                                "top_p": {"type": "number"}
                            },
                            "required": ["max_new_tokens", "top_p"]
                        }
                    },
                    "required": ["query"]
                },
                "application/png": {
                    "$schema": "http://json-schema.org/draft-07/schema#",
                    "type": "object",
                    "properties": {
                        "image": {"type": "string", "format": "binary"}
                    },
                    "required": ["image"]
                }
            },
            "response": {
                "application/json": {
                    "$schema": "http://json-schema.org/draft-07/schema#",
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "result": {"type": "string"}
                    },
                    "required": ["query", "result"]
                },
                "application/png": {
                    "$schema": "http://json-schema.org/draft-07/schema#",
                    "type": "string",
                    "format": "binary"
                }
            }
        }
    }

    headers = {
        "Authorization": token,
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 201:
        print("✅ AI service created successfully.")
        print(response.json())
    else:
        print("❌ Failed:", response.status_code, response.text)

# Run this function
register_ai_service() 