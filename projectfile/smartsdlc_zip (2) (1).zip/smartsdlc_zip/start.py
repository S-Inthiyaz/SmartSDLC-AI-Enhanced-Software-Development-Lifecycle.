#!/usr/bin/env python3
"""
SmartSDLC Startup Script
Launches the SmartSDLC application with proper configuration
"""

import os
import sys
import subprocess
import webbrowser
import time
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Error: Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        sys.exit(1)
    print(f"✅ Python version: {sys.version.split()[0]}")

def check_dependencies():
    """Check if required dependencies are installed"""
    try:
        import fastapi
        import uvicorn
        import fitz  # PyMuPDF
        print("✅ All required dependencies are installed")
        return True
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("Please install dependencies with: pip install -r backend/requirements.txt")
        return False

def create_env_file():
    """Create .env file if it doesn't exist"""
    env_path = Path("backend/.env")
    if not env_path.exists():
        print("📝 Creating .env file...")
        env_content = """# SmartSDLC Environment Configuration
# Replace with your actual API keys

# HuggingFace API Key (required)
HF_API_KEY=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

# Watsonx Granite-20B Model ID
WATSONX_MODEL_ID=ibm/granite-20b-code-instruct

# HuggingFace Model ID (fallback)
HF_MODEL_ID=bigcode/starcoder

# Server Configuration
HOST=0.0.0.0
PORT=8000
DEBUG=true
"""
        env_path.write_text(env_content)
        print("✅ Created .env file in backend directory")
        print("⚠️  Please update the API keys in backend/.env with your actual keys")
    else:
        print("✅ .env file already exists")

def start_backend():
    """Start the FastAPI backend server"""
    print("🚀 Starting SmartSDLC backend server...")
    
    backend_dir = Path("backend")
    if not backend_dir.exists():
        print("❌ Backend directory not found")
        return False
    
    os.chdir(backend_dir)
    
    try:
        # Start the server
        cmd = [
            sys.executable, "-m", "uvicorn", 
            "main:app", 
            "--reload", 
            "--host", "0.0.0.0", 
            "--port", "8000"
        ]
        
        print("🌐 Backend server starting at: http://localhost:8000")
        print("📚 API documentation at: http://localhost:8000/docs")
        print("🔄 Auto-reload enabled")
        print("⏹️  Press Ctrl+C to stop the server")
        print("-" * 50)
        
        subprocess.run(cmd)
        return True
        
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
        return True
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        return False

def open_frontend():
    """Open the frontend in the default browser"""
    frontend_path = Path("frontend/index.html")
    if frontend_path.exists():
        print("🌐 Opening frontend in browser...")
        webbrowser.open(f"file://{frontend_path.absolute()}")
    else:
        print("❌ Frontend file not found")

def main():
    """Main startup function"""
    print("🚀 SmartSDLC - AI Powered SDLC Automation")
    print("=" * 50)
    
    # Check Python version
    check_python_version()
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Create .env file if needed
    create_env_file()
    
    print("\n🎯 Starting SmartSDLC...")
    print("📋 Features available:")
    print("   • Requirements Classification")
    print("   • AI Code Generation")
    print("   • Bug Fixing & Analysis")
    print("   • Test Case Generation")
    print("   • Code Summarization")
    print("   • AI Chatbot Assistant")
    
    # Start backend server
    if start_backend():
        print("✅ SmartSDLC started successfully!")
    else:
        print("❌ Failed to start SmartSDLC")
        sys.exit(1)

if __name__ == "__main__":
    main() 