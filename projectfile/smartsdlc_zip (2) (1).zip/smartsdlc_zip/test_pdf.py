#!/usr/bin/env python3
"""
Test script to verify PyMuPDF functionality
"""

import fitz
import os

def test_pymupdf():
    """Test PyMuPDF functionality"""
    print("🧪 Testing PyMuPDF functionality...")
    
    try:
        # Test basic functionality
        print("✅ PyMuPDF imported successfully")
        print(f"📦 PyMuPDF version: {fitz.version}")
        
        # Test document creation (we'll create a simple test PDF)
        doc = fitz.open()  # type: ignore
        page = doc.new_page()
        page.insert_text((50, 50), "Test PDF for SmartSDLC")
        page.insert_text((50, 100), "This is a test document.")
        page.insert_text((50, 150), "Requirements: User authentication system")
        page.insert_text((50, 200), "Design: Database schema for users")
        page.insert_text((50, 250), "Development: Implement login API")
        
        # Save test PDF
        test_pdf_path = "test_document.pdf"
        doc.save(test_pdf_path)
        doc.close()
        
        print(f"✅ Test PDF created: {test_pdf_path}")
        
        # Test reading the PDF
        doc = fitz.open(test_pdf_path)  # type: ignore
        text = ""
        for page in doc:
            text += page.get_text()  # type: ignore
        doc.close()
        
        print("✅ PDF text extraction successful")
        print(f"📄 Extracted text length: {len(text)} characters")
        print("📝 Sample text:")
        print(text[:200] + "..." if len(text) > 200 else text)
        
        # Clean up
        if os.path.exists(test_pdf_path):
            os.remove(test_pdf_path)
            print("✅ Test file cleaned up")
        
        print("🎉 All PyMuPDF tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ PyMuPDF test failed: {e}")
        return False

if __name__ == "__main__":
    test_pymupdf() 